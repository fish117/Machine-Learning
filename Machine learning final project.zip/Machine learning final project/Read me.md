Hi professor,

Our final report is in PDF format, in which we conduct the exploratory analysis using Tableau. The link for Tableau analysis is specified in document as well.

Since we ran several combinations of hyperparameters for random forest model, it might take a long time to process. Thus we split the R code for random forest and Loess&SVM, which are labeled clearly in the folder.

Thanks for your time.