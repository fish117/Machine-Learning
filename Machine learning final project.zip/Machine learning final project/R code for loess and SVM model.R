#####################################################
# BAIT 509 Final Project
#####################################################

library("randomForest")
library("ggplot2")
library("dplyr")
library("tidyr")
library("class")
library("tree")

#########################################
# Read the data
#########################################

dat.orig <- read.csv(file = "/Users/arielsun/Desktop/city-crime-master/data/ucr_crime_1975_2015.csv")

#########################################
# Decide how to clean the data
#########################################

sum(complete.cases(dat.orig[,-c(16, 17)])) #2688 observations are complete
nrow(dat.orig) #2829
(2829-2688)/2829 #4.98% incomplete data

########################################################
# Tranpose the dataframe, gather the data of every city
########################################################

city <- unique(dat.orig$department_name)
city

dat.orig[1,]

dat <- data.frame(matrix(ncol = 41*6+1))

for (i in 1: length(city)) {
  
  dat.try <- filter(dat.orig, dat.orig$department_name == city[i])
  a <- list(city[i])
  
  for (t in 1: length(dat.try)) {
    
    a <- append(a, c(dat.try$agg_ass_per_100k, dat.try$violent_per_100k, dat.try$homs_per_100k, dat.try$rape_per_100k, dat.try$rob_per_100k, dat.try$months_reported))
    
  }
  
  dat <- rbind(dat, a)
  
}

dat <- dat[-1, ]

#########################################
# Change the colnames of final dataframe
#########################################

name_lst = list()
name_lst = append(name_lst, "City")

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Crime", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Violent", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Homs", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Rape", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Rob", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("MonthReported", i, sep=""))
}

colnames(dat) <- c(name_lst)
dat$MonthReported2015 <- 12
#########################################
# Decide how to clean the data
#########################################

# Remove Louisville since the data begins only at 2002
# Remove Naitonal since it contains little data
dat <- dat[-c(31, 41), ]

# How many obs left
sum(complete.cases(dat)) #61 observations are complete
nrow(dat) #Total 67 obs
(67-61)/67 #8.96% incomplete data

dat <- na.omit(dat)

#########################################
# Change the month effect
#########################################

dat.month <- dat[ ,207:247]
summary(dat.month)

for (i in 2:41) {
  
  for (t in 1:61) {
    
    dat.month[t,i] <- ifelse(dat.month[t,i] == 0, 12, dat.month[t,i])
    
  }
  
}

dat.month <- cbind(dat$City, dat.month, dat.month, dat.month, dat.month, dat.month)
str(dat.month)

dat.new <- data.frame(matrix(ncol = 206, nrow = 61))
colnames(dat.new) <- c(name_lst[1:206])
dat.new$City <- dat$City

for (i in 2:206) {
  
  dat.new[,i] <- dat[,i] / dat.month[,i] * 12
  
}

#########################################
# Seperate the dataset into 5 categories
#########################################

dat.ass <- dat.new[ ,c(1, 2:42)]
dat.violent <- dat.new[ ,c(1, 43:83)]
dat.homs <- dat.new[ ,c(1, 84:124)]
dat.rape <- dat.new[ ,c(1, 125:165)]
dat.rob <- dat.new[ ,c(1, 166:206)]

#########################################
# Lag---violent
#########################################

lag.violent <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.violent[t,i] <- dat.violent[t,i+1] / dat.violent[t,i]
    
  }
  
}

try_violent = lag.violent[,35:41]

#loess 
loess_violent <- loess.as(try_violent[,5:6],try_violent$X41,  degree = 1, criterion = c("aicc", "gcv")[2], user.span = NULL, plot = F)
pre_loess_violent <- predict(loess_violent)
MSE_loess_violent <- mean((pre_loess_violent  - try_violent[,7])^2)
loess_violent$pars$span

# SVM_linear
tuned_linear_crime <- tune.svm(X41~ ., data = try_violent, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="linear")
summary(tuned_linear_crime)

# SVM_rbf
tuned_radial_crime<- tune.svm(X41~ ., data = try_violent, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="radial")
summary(tuned_radial_crime)

#prediction:
pre_violent_rate<-predict(loess_violent,data=try_violent[,6:7])
pre_violent<-pre_violent_rate*dat.violent$Violent2015
pre_violent_total<-cbind(dat$City,pre_violent)
pre_violent_total[which.min(pre_violent),]
pre_violent_total[which.max(pre_violent),]

#########################################
# Lag---ass
#########################################

lag.ass <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.ass[t,i] <- dat.ass[t,i+1] / dat.ass[t,i]
    
  }
  
}

try_ass = lag.ass[,35:41]

#loess 
loess_ass<- loess.as(try_ass[,5:6],try_violent$X41,  degree = 1, criterion = c("aicc", "gcv")[2], user.span = NULL, plot = F)
pre_loess_ass<- predict(loess_ass)
MSE_loess_ass<-mean((pre_loess_ass  - try_ass[,7])^2)
loess_ass$pars$span

# SVM_linear
tuned_linear_ass <- tune.svm(X41~ ., data = try_ass, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="linear")
summary(tuned_linear_ass)

# SVM_rbf
tuned_radial_ass<- tune.svm(X41~ ., data = try_ass, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="radial")
summary(tuned_radial_ass)

#prediction:
pre_ass_rate<-predict(loess_ass,data=try_ass[,6:7])
pre_ass<-pre_ass_rate*dat.ass$Crime2015
pre_ass_total<-cbind(dat$City,pre_ass)
pre_ass_total[which.min(pre_ass),]
pre_ass_total[which.max(pre_ass),]


#########################################
# Lag---rob
#########################################

lag.rob <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.rob[t,i] <- dat.rob[t,i+1] / dat.rob[t,i]
    
  }
  
}

try_rob = lag.rob[,35:41]

#loess 
loess_rob<- loess.as(try_ass[,5:6],try_rob$X41,  degree = 1, criterion = c("aicc", "gcv")[2], user.span = NULL, plot = F)
pre_loess_rob<- predict(loess_rob)
MSE_loess_rob<-mean((pre_loess_rob  - try_rob[,7])^2)
loess_rob$pars$span

# SVM_linear
tuned_linear_rob <- tune.svm(X41~ ., data = try_rob, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="linear")
summary(tuned_linear_rob)

# SVM_rbf
tuned_radial_rob<- tune.svm(X41~ ., data = try_rob, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="radial")
summary(tuned_radial_rob)

#prediction:
pre_rob_rate<-predict(loess_rob,data=try_rob[,6:7])
pre_rob<-pre_rob_rate*dat.rob$Rob2015
pre_rob_total<-cbind(dat$City,pre_rob)
pre_rob_total[which.min(pre_rob),]
pre_rob_total[which.max(pre_rob),]

#########################################
# Lag---rape
#########################################

lag.rape <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.rape[t,i] <- dat.rape[t,i+1] / dat.rape[t,i]
    
  }
  
}

try_rape = lag.rape[,35:41]

#loess 
loess_rape<- loess.as(try_rape[,5:6],try_rape$X41,  degree = 1, criterion = c("aicc", "gcv")[2], user.span = NULL, plot = F)
pre_loess_rape<- predict(loess_rape)
MSE_loess_rape<-mean((pre_loess_rape  - try_rape[,7])^2)
loess_rape$pars$span

# SVM_linear
tuned_linear_rape <- tune.svm(X41~ ., data = try_rape, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="linear")
summary(tuned_linear_rape)

# SVM_rbf
tuned_radial_rape<- tune.svm(X41~ ., data = try_rape, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="radial")
summary(tuned_radial_rape)

#prediction:
pre_rape_rate<-predict(loess_rape,data=try_rape[,6:7])
pre_rape<-pre_rape_rate*dat.rape$Rape2015
pre_rape_total<-cbind(dat$City,pre_rob)
pre_rape_total[which.min(pre_rape),]
pre_rape_total[which.max(pre_rape),]
#########################################
# Lag---homs
#########################################

lag.homs <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.homs[t,i] <- dat.homs[t,i+1] / dat.homs[t,i]
    
  }
  
}

try_homs = lag.homs[,35:41]

#loess 
loess_homs<- loess.as(try_homs[,5:6],try_homs$X41,  degree = 1, criterion = c("aicc", "gcv")[2], user.span = NULL, plot = F)
pre_loess_homs<- predict(loess_homs)
MSE_loess_homs<-mean((pre_loess_homs  - try_homs[,7])^2)
loess_homs$pars$span

# SVM_linear
tuned_linear_homs<- tune.svm(X41~ ., data = try_homs, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="linear")
summary(tuned_linear_homs)

# SVM_rbf
tuned_radial_homs<- tune.svm(X41~ ., data = try_homs, gamma = 10^(-6:-1), cost = 10^(1:2), kernel="radial")
summary(tuned_radial_homs)

#prediction:
pre_homs_rate<-predict(loess_homs,data=try_homs[,6:7])
pre_homs<-pre_rape_rate*dat.homs$Homs2015
pre_homs_total<-cbind(dat$City,pre_homs)
pre_homs_total[which.min(pre_homs),]
pre_homs_total[which.max(pre_homs),]

#total prediction
total_pre<-cbind(dat$City,pre_loess_violent,pre_violent,pre_loess_ass,pre_ass,pre_loess_rob,pre_rob,pre_loess_rape,pre_rape,pre_loess_homs,pre_homs)
