#####################################################
# BAIT 509 Final Project
#####################################################

library("randomForest")
library("ggplot2")
library("dplyr")
library("tidyr")
library("class")
library("tree")

#########################################
# Read the data
#########################################

dat.orig <- read.csv(file = "/Users/arielsun/Desktop/city-crime-master/data/ucr_crime_1975_2015.csv")

#########################################
# Decide how to clean the data
#########################################

sum(complete.cases(dat.orig[,-c(16, 17)])) #2688 observations are complete
nrow(dat.orig) #2829
(2829-2688)/2829 #4.98% incomplete data

########################################################
# Tranpose the dataframe, gather the data of every city
########################################################

city <- unique(dat.orig$department_name)
city

dat.orig[1,]

dat <- data.frame(matrix(ncol = 41*6+1))

for (i in 1: length(city)) {
  
  dat.try <- filter(dat.orig, dat.orig$department_name == city[i])
  a <- list(city[i])
  
  for (t in 1: length(dat.try)) {
    
    a <- append(a, c(dat.try$agg_ass_per_100k, dat.try$violent_per_100k, dat.try$homs_per_100k, dat.try$rape_per_100k, dat.try$rob_per_100k, dat.try$months_reported))
    
  }
  
  dat <- rbind(dat, a)
  
}

dat <- dat[-1, ]

#########################################
# Change the colnames of final dataframe
#########################################

name_lst = list()
name_lst = append(name_lst, "City")

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Crime", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Violent", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Homs", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Rape", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("Rob", i, sep=""))
}

for(i in 1975:2015){
  name_lst = append(name_lst, paste("MonthReported", i, sep=""))
}

colnames(dat) <- c(name_lst)
dat$MonthReported2015 <- 12
#########################################
# Decide how to clean the data
#########################################

# Remove Louisville since the data begins only at 2002
# Remove Naitonal since it contains little data
dat <- dat[-c(31, 41), ]

# How many obs left
sum(complete.cases(dat)) #61 observations are complete
nrow(dat) #Total 67 obs
(67-61)/67 #8.96% incomplete data

dat <- na.omit(dat)

#########################################
# Change the month effect
#########################################

dat.month <- dat[ ,207:247]
summary(dat.month)

for (i in 2:41) {
  
  for (t in 1:61) {
    
    dat.month[t,i] <- ifelse(dat.month[t,i] == 0, 12, dat.month[t,i])
    
  }
  
}

dat.month <- cbind(dat$City, dat.month, dat.month, dat.month, dat.month, dat.month)
str(dat.month)

dat.new <- data.frame(matrix(ncol = 206, nrow = 61))
colnames(dat.new) <- c(name_lst[1:206])
dat.new$City <- dat$City

for (i in 2:206) {

  dat.new[,i] <- dat[,i] / dat.month[,i] * 12
    
}

#########################################
# Seperate the dataset into 5 categories
#########################################

dat.ass <- dat.new[ ,c(1, 2:42)]
dat.violent <- dat.new[ ,c(1, 43:83)]
dat.homs <- dat.new[ ,c(1, 84:124)]
dat.rape <- dat.new[ ,c(1, 125:165)]
dat.rob <- dat.new[ ,c(1, 166:206)]

#########################################
# Lag
#########################################

#Violent
lag.violent <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.violent[t,i] <- dat.violent[t,i+1] / dat.violent[t,i]
    
  }
  
}

#Ass
lag.ass <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.ass[t,i] <- dat.ass[t,i+1] / dat.ass[t,i]
    
  }
  
}

#Homs
lag.homs <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.homs[t,i] <- dat.homs[t,i+1] / dat.homs[t,i]
    
  }
  
}

#Rape
lag.rape <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.rape[t,i] <- dat.rape[t,i+1] / dat.rape[t,i]
    
  }
  
}

#Rab
lag.rob <- data.frame(matrix(ncol = 41, nrow = 61))

for (i in 2:41) {
  
  for (t in 1:61) {
    
    lag.rob[t,i] <- dat.rob[t,i+1] / dat.rob[t,i]
    
  }
  
}

#########################################
# Violent
#########################################

# Random forest

# n = 10

try = lag.violent[,31:41]

dat.rand = data.frame()

for (i in seq(3, 10, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

# n = 15

try = lag.violent[,26:41]

dat.rand = data.frame()

for (i in seq(4, 15, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(6)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

# n = 20

try = lag.violent[,21:41]

dat.rand = data.frame()

for (i in seq(10, 20, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

# n = 25

try = lag.violent[,16:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

# n = 30

try = lag.violent[,11:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

# n = 35

try = lag.violent[,6:41]

dat.rand = data.frame()

for (i in seq(16, 30, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Total Crime') +
  theme_set(theme_bw())

#Final model for violent

try = lag.violent[,26:41]
try.pred = lag.violent[,27:41]
colnames(try.pred) <- colnames(try[,1:15])

dat.rand = data.frame()

set.seed(6)
fit <- randomForest(X41 ~ ., 
                    data = try, 
                    mtry = 14,
                    ntree = 250)
summary(fit)
yhat <- predict(fit)
yhat.pred <- predict(fit, newdata = try.pred)
oob <- mean((yhat - try$X41)^2)

pred.violent <- data.frame(matrix(ncol = 2, nrow = 61))
pred.violent$X1 <- dat.new$City
pred.violent$X2 <- yhat.pred*dat.new$Violent2015
colnames(pred.violent) <- c("city", "predicted ratio")
oob

#################################################
# Assault
#################################################

# Random Forest

# n = 10

try = lag.ass[,31:41]

dat.rand = data.frame()

for (i in seq(3, 10, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# n = 15

try = lag.ass[,26:41]

dat.rand = data.frame()

for (i in seq(4, 15, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(6)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# n = 20

try = lag.ass[,21:41]

dat.rand = data.frame()

for (i in seq(10, 20, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# n = 25

try = lag.ass[,16:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# n = 30

try = lag.ass[,11:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# n = 35

try = lag.ass[,6:41]

dat.rand = data.frame()

for (i in seq(16, 30, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Assault') +
  theme_set(theme_bw())

# Final model for assault

try = lag.ass[,11:41]
try.pred = lag.ass[,12:41]
colnames(try.pred) <- colnames(try[,1:30])

dat.rand = data.frame()

set.seed(1)
fit <- randomForest(X41 ~ ., 
                    data = try, 
                    mtry = 14,
                    ntree = 250)
summary(fit)
yhat <- predict(fit)
yhat.pred <- predict(fit, newdata = try.pred)
oob <- mean((yhat - try$X41)^2)

pred.ass <- data.frame(matrix(ncol = 2, nrow = 61))
pred.ass$X1 <- dat.new$City
pred.ass$X2 <- yhat.pred*dat.new$Crime2015
colnames(pred.ass) <- c("city", "predicted ratio")
oob

#################################################
# Homicide
#################################################

# Random Forest

# n = 10

try = lag.homs[,31:41]

dat.rand = data.frame()

for (i in seq(3, 10, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# n = 15

try = lag.homs[,26:41]

dat.rand = data.frame()

for (i in seq(4, 15, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(6)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# n = 20

try = lag.homs[,21:41]

dat.rand = data.frame()

for (i in seq(10, 20, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# n = 25

try = lag.homs[,16:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# n = 30

try = lag.homs[,11:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# n = 35

try = lag.homs[,6:41]

dat.rand = data.frame()

for (i in seq(16, 30, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Homicide') +
  theme_set(theme_bw())

# Final model for Homicide

try = lag.homs[,11:41]
try.pred = lag.homs[,12:41]
colnames(try.pred) <- colnames(try[,1:30])

dat.rand = data.frame()

set.seed(1)
fit <- randomForest(X41 ~ ., 
                    data = try, 
                    mtry = 23,
                    ntree = 125)
summary(fit)
yhat <- predict(fit)
yhat.pred <- predict(fit, newdata = try.pred)
oob <- mean((yhat - try$X41)^2)

pred.ass <- data.frame(matrix(ncol = 2, nrow = 61))
pred.ass$X1 <- dat.new$City
pred.ass$X2 <- yhat.pred*dat.new$Homs2015
colnames(pred.ass) <- c("city", "predicted ratio")
oob

#################################################
# Rape
#################################################

# Random Forest

# n = 10

try = lag.rape[,31:41]

dat.rand = data.frame()

for (i in seq(3, 10, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 15

try = lag.rape[,26:41]

dat.rand = data.frame()

for (i in seq(4, 15, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(6)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 20

try = lag.rape[,21:41]

dat.rand = data.frame()

for (i in seq(10, 20, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 25

try = lag.rape[,16:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 30

try = lag.rape[,11:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 35

try = lag.rape[,6:41]

dat.rand = data.frame()

for (i in seq(16, 30, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# Final model for Rape

try = lag.rape[,31:41]
try.pred = lag.rape[,32:41]
colnames(try.pred) <- colnames(try[,1:10])

dat.rand = data.frame()

set.seed(1)
fit <- randomForest(X41 ~ ., 
                    data = try, 
                    mtry = 5,
                    ntree = 125)
summary(fit)
yhat <- predict(fit)
yhat.pred <- predict(fit, newdata = try.pred)
oob <- mean((yhat - try$X41)^2)

pred.ass <- data.frame(matrix(ncol = 2, nrow = 61))
pred.ass$X1 <- dat.new$City
pred.ass$X2 <- yhat.pred*dat.new$Rape2015
colnames(pred.ass) <- c("city", "predicted ratio")
oob

#################################################
# Rob
#################################################

# Random Forest

# n = 10

try = lag.rob[,31:41]

dat.rand = data.frame()

for (i in seq(3, 10, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rob') +
  theme_set(theme_bw())

# n = 15

try = lag.rob[,26:41]

dat.rand = data.frame()

for (i in seq(4, 15, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(6)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rob') +
  theme_set(theme_bw())

# n = 20

try = lag.rob[,21:41]

dat.rand = data.frame()

for (i in seq(10, 20, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# n = 25

try = lag.rob[,16:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rob') +
  theme_set(theme_bw())

# n = 30

try = lag.rob[,11:41]

dat.rand = data.frame()

for (i in seq(16, 25, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rob') +
  theme_set(theme_bw())

# n = 35

try = lag.rob[,6:41]

dat.rand = data.frame()

for (i in seq(16, 30, 1)) {
  
  for (t in seq(25, 2025, 100)) {
    set.seed(1)
    fit <- randomForest(X41 ~ ., 
                        data = try, 
                        mtry = i,
                        ntree = t)
    yhat <- predict(fit)
    oob <- mean((yhat - try$X41)^2)
    dat.rand <- rbind(dat.rand,
                      c(
                        i,
                        t,
                        oob
                      ))
  }
  
}

colnames(dat.rand) <- c("mtry", "ntree", "OOBError")
dat.rand$mtry <- as.factor(dat.rand$mtry)

ggplot(dat.rand, aes(ntree, OOBError)) +
  geom_line(aes(group = mtry, color = mtry)) +
  xlab("Number of trees") +
  ylab("Out-of-bag Error") +
  ggtitle('Relationship between OOB error and ntree for Rape') +
  theme_set(theme_bw())

# Final model for Rob

try = lag.rob[,26:41]
try.pred = lag.rob[,27:41]
colnames(try.pred) <- colnames(try[,1:15])

dat.rand = data.frame()

set.seed(6)
fit <- randomForest(X41 ~ ., 
                    data = try, 
                    mtry = 9,
                    ntree = 125)
summary(fit)
yhat <- predict(fit)
yhat.pred <- predict(fit, newdata = try.pred)
oob <- mean((yhat - try$X41)^2)

pred.ass <- data.frame(matrix(ncol = 2, nrow = 61))
pred.ass$X1 <- dat.new$City
pred.ass$X2 <- yhat.pred*dat.new$Rob2015
colnames(pred.ass) <- c("city", "predicted ratio")
oob
